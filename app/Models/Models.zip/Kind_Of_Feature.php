<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kind_Of_Feature extends Model 
{

    protected $table = 'kinds_of_features';
    public $timestamps = true;

}